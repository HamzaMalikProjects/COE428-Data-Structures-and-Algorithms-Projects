#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define NUM_STATES 8

// State struct
typedef struct State {
    char name;  // name of the state (A-H)
    int next_states[2];  // index of next state for input 0 and input 1 respectively
    bool is_deleted;  // flag to indicate if the state is deleted or not
} State;

// Global state machine array
State state_machine[NUM_STATES];

// Global variable to store the current state index
int current_state_index = 0;

// Initialize the state machine
void initialize() {
    state_machine[0] = (State) {'A', {5, 6}, false};
    state_machine[1] = (State) {'B', {4, 2}, false};
    state_machine[2] = (State) {'C', {2, 0}, false};
    state_machine[3] = (State) {'D', {6, 4}, false};
    state_machine[4] = (State) {'E', {1, 7}, false};
    state_machine[5] = (State) {'F', {7, 3}, false};
    state_machine[6] = (State) {'G', {5, 1}, false};
    state_machine[7] = (State) {'H', {2, 3}, false};
}

// Get the next state index for the given input (0 or 1)
int get_next_state_index(int input) {
    return state_machine[current_state_index].next_states[input];
}

// Update the current state index for the given input (0 or 1)
void update_current_state(int input) {
    int next_state_index = get_next_state_index(input);
    while (state_machine[next_state_index].is_deleted) {
        printf("State deleted cannot be accessed\n");
        return;
    }
    current_state_index = next_state_index;
}

// Check if a state is reachable from the current state
bool is_reachable(int state_index, bool visited[]) {
    // Use depth-first search to check reachability
    if (state_machine[state_index].is_deleted) {
        return false;
    }
    visited[state_index] = true;
    for (int i = 0; i < 2; i++) {
        int next_state_index = state_machine[state_index].next_states[i];
        if (!visited[next_state_index] && !state_machine[next_state_index].is_deleted) {
            if (is_reachable(next_state_index, visited)) {
                return true;
            }
        }
    }
    return false;
}

// Change the next state index for the given input (0 or 1) to the specified state
void change_state(char state_name, int input_value) {
    int state_index = state_name - 'A';
    if (state_index < 0 || state_index >= NUM_STATES) {
        printf("Invalid state name.\n");
        return;
    }
    state_machine[current_state_index].next_states[input_value] = state_index;
}
// Print's the state machine configuration as currently specified
void print_state_machine() {
    printf("State machine configuration:\n");
    for (int i = 0; i < NUM_STATES; i++) {
        State state = state_machine[i];
        if (!state.is_deleted) {
            printf("%c: %d %d\n", state.name, state.next_states[0], state.next_states[1]);
        }
    }
    printf("\n");
}

// Identify all states that are reachable or unreachable from the current state
void identify_garbage() {
    // Use depth-first search to mark all reachable states
    bool visited[NUM_STATES] = {false};
    is_reachable(current_state_index, visited);

    // Check which states are unreachable
    bool has_garbage = false;
    printf("Garbage (Unreachable States): ");
    for (int i = 0; i < NUM_STATES; i++) {
        if (!visited[i] && !state_machine[i].is_deleted) {
            printf(" %c ", state_machine[i].name);
            has_garbage = true;
        }
    }
    if (!has_garbage) {
        printf("No garbage");
    }
    printf("\n");
}

void delete_state(State *sm, char state_id) {
    if (state_id == 'd') {
        // Delete all unreachable states
        bool visited[NUM_STATES] = {false};
        is_reachable(current_state_index, visited);
        bool any_deleted = false;
        for (int i = 0; i < NUM_STATES; i++) {
            if (!visited[i] && !state_machine[i].is_deleted) {
                sm[i].is_deleted = true;
                any_deleted = true;
                printf("%c", sm[i].name);
            }
        }
        if (any_deleted) {
            printf("\nDeleted all unreachable states.\n");
            update_current_state(0);
        } else {
            printf("No states deleted.\n");
        }
    } else {
        // Delete the specified state (if it is not reachable)
        bool visited[NUM_STATES] = {false};
        bool any_deleted = false;
        for (int i = 0; i < NUM_STATES; i++) {
            if (sm[i].name == state_id && !is_reachable(i, visited)) {
                sm[i].is_deleted = true;
                any_deleted = true;
            }
        }
        if (!any_deleted) {
            printf("Error: state with id %c not found or is reachable.\n", state_id);
        } else {
            update_current_state(0);
            is_reachable(current_state_index, visited);
        }
    }
}

int main() {
    // Initialize the state machine
    initialize();

    // Run the state machine
    char input;
    while (1) {
        printf("Current state: %c\n", state_machine[current_state_index].name);
        printf("Enter input (0 or 1) or command (g to identify garbage, c to change state, d to delete state, p to print state machine, q to quit): ");
        scanf(" %c", &input);

        switch (input) {
            case '0':
                update_current_state(0);
                break;
            case '1':
                update_current_state(1);
                break;
            case 'g':
                identify_garbage();
                break;
            case 'c': {
                char state_name;
                int input_value;
                printf("Enter state name (A-H): ");
                scanf(" %c", &state_name);
                printf("Enter input value (0 or 1): ");
                scanf("%d", &input_value);
                change_state(state_name, input_value);
                break;
            }
            case 'd': {
                char state_name;
                printf("Enter state name (A-H) to delete or enter 'd' again to delete all unreachable states: ");
                scanf(" %c", &state_name);
                delete_state(state_machine, state_name);
                break;
            }
            case 'p':
                print_state_machine();
                break;
            case 'q':
                return 0;
            default:
                printf("Invalid input.\n");
                break;
        }
    }
    return 0;
}




  

