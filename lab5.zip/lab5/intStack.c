/**
 *  The functions in this module implement a Stack data structure
 *  of integers.  (Note that chars are also integers so this
 *  integer Stack can be used for chars as well.)
 *
 *  NOTE: the stack is implemented as a fixed size array (size = 100).
 *  Consequently, no more than 100 integers can be pushed onto
 *  the Stack at any given time.
 */

// Implementation hints:
//   The 3 functions--push, pop and isEmpty--share information
//   about the array used to implement the stack and the index
//   of the "top" of the stack.
//
//   You may want to make these variables global...
//   ...but that would
//   be a mistake (because anyone using the module would have
//   to ensure that they did not use global variables with the
//   same names).
//
//   An alternative in C is a "static global".
//   If a global variable is qualified as "static", it is global only
//   within the source code file where it is declared.
//   In parituclar, it cannot conflict with any other global variable.
//
//  RECOMMENDATION:
//   Uncomment the following 2 lines and use these static globals!

/**
 * pop() removes the top integer on the stack and returns it.
 *
 * If pop() is attempted on an empty stack, an error message
 * is printed to stderr and the value -1 is returned.
 */


#include <stdio.h>
// Initially, the stack is empty, so 'top' is set to 0.
static int top = 0;
// 'stack' is an array of 100 integers, representing the stack itself.
static int stack[100];


/**
 * pop() removes the top integer on the stack and returns it.
 *
 * If pop() is attempted on an empty stack, an error message
 * is printed to stderr and the value -1 (minus one) is returned.
 */

int pop()
{
// If the 'top' is 0, the stack is empty.
  if (top == 0) {
    fprintf(stderr, "Error: Stack is empty.\n");
    return -1;
  }
 // Decrease the 'top' to get the current top element and return it.
  return stack[--top];
}

/**
 *  push(thing2push) adds the "thing2push" to the top of the stack.
 *
 *  If there is no more space available on the Stack, an error
 *  message is printed to stderr.
 */
void push(int thing2push)
{
  // If 'top' is 100, it means the stack is full.
  if (top == 100) {
    fprintf(stderr, "Error: Stack is full.\n");
    return;
  }
 // Push the 'thing2push' to the current 'top' position and then increment the 'top'.
  stack[top++] = thing2push;
}

/**
 * isEmpty() returns a non-zero integer (not necessarily 1) if the
 * stack is empty; otherwise, it returns 0 (zero).
 *
 */
int isEmpty()
{
 // If 'top' is 0, the stack is empty and returns 1 (true), otherwise returns 0 (false).
  return top == 0;
}
